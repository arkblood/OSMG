package namoosori.oops.radio.util;

public interface Player {
	//
	public String getName(); 
}