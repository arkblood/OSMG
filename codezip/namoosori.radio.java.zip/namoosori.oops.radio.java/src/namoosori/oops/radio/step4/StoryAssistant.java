package namoosori.oops.radio.step4;

import namoosori.oops.radio.step4.ui.RadioCli;

public class StoryAssistant {
	// 
	
	public static void main(String[] args) {
		// 
		startStory(); 
	}
	
	public static void startStory() {
		// 
		(new RadioCli()).showMenuAndAction(); 
	}
}